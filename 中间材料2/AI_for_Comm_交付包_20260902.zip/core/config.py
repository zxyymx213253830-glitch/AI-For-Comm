# -*- coding: utf-8 -*-
"""
AI for Comm 集中配置管理 —— OpenTrek 平台版

学校平台是 OpenTrek（非百炼公有云），API 走 HTTP 直接调用。

API 文档（详见项目根目录 PDF）：
  1. createSession    → 创建 Agent 会话，返回 uniqueCode
  2. /run（stream）    → 发起对话，SSE 流式返回
  3. createNewChannel → SSE 长连接（复杂场景用，本项目暂不需要）
  4. 知识库检索        → 直接检索知识库内容

调用流程（本项目采用）：
  createSession → /run(stream=true) → 解析 SSE → 提取文本回答
"""
from typing import Dict

# ── OpenTrek API 端点 ───────────────────────────────────
OPENTREK_BASE_URL = (
    "http://10.128.203.200:80"
    "/sfm-agent-studio/sfm-api-gateway/gateway/agent/api"
)
APP_KEY = "C8YA4uLQ66q4ggl09WKsI4OAgapASqoY"

# ── 超时配置 ────────────────────────────────────────────
REQUEST_TIMEOUT = 300  # 单次请求超时（秒），数学推导可能耗时较长
SSE_READ_TIMEOUT = 300  # SSE 流读取超时（秒）

# ── Agent 注册表 ───────────────────────────────────────
# agentCode:    OpenTrek 控制台 → Agent 详情 → 编号（UUID 格式）
# agentVersion: OpenTrek 控制台 → Agent 详情 → 版本编码（数字字符串）
AGENTS: Dict[str, dict] = {
    "math_agent": {
        "agentCode":    "d0778d9a-16b1-4e0b-81d7-d060bdfed564",
        "agentVersion": "1786194666467",  # v2.0（已上线）；旧 v1.0=1785333639040 已下线，勿用
        "kbIds":        ["t6doo3pjacqe"],  # 信息论数学标准库
        "description":  "数学推导 Agent — 负责信息论公式推导与信道容量计算",
    },
    "verify_agent": {
        "agentCode":    "fed235c6-e97c-431e-b7e1-2cec6200ad9d",
        "agentVersion": "1788075577472",  # v5.1（已上线）；旧 v5.0=1786025588539 已下线，勿用
        "kbIds":        [],  # 验证 Agent 不需要知识库
        "description":  "验证 Agent — 负责检查推导正确性并给出反馈",
    },
    "comm_agent": {
        "agentCode":    "72d8241c-55cf-4dc7-9f2a-d9e464ff13b8",
        "agentVersion": "1787757082841",  # v5.0（已上线）；旧 v4.0=1786025488961 已下线，勿用
        "kbIds":        ["jka3mxb19y08", "anb7bpimm2jn"],  # 3GPP_KB + 3GPP_Document_KB
        "description":  "通信工程 Agent — 负责 3GPP 协议查询与信令流程分析（GTPv2/S1AP/NGAP/NAS）",
    },
    "hw_agent": {
        "agentCode":    "62d77ba3-1a25-4b67-8728-13617e543e19",
        "agentVersion": "1786113673445",  # v7.2（已上线）；旧 v7.1=1786108796196 报 HTTP 500，勿用
        "kbIds":        ["jfoi1hlf60e7", "d8xgrvwu8zr7"],  # FPGA_Fundamentals + FPGA_Vivado_Tooling
        "description":  "硬件实践 Agent — 负责 FPGA / Verilog 模块生成与时序分析",
    },
    "lit_review_agent": {
        "agentCode":    "ada4212a-c471-42a7-84a0-26e7a23b520f",
        "agentVersion": "1787753150262",
        "kbIds":        ["jka3mxb19y08", "anb7bpimm2jn"],  # 3GPP_KB + 3GPP_Document_KB
        "description":  "文献调研 Agent — 负责通信领域文献检索、归纳与综述生成",
    },
    "sim_agent": {
        "agentCode":    "c1c9aa5f-f657-49d0-9999-25a2969c3345",
        "agentVersion": "1787760897423",  # v1.0（已上线，周行远创建）
        "kbIds":        [],  # 数值仿真不依赖知识库；如需信道模型资料可挂载
        "description":  "仿真 Agent — 通信数值仿真（BER/容量曲线），真执行代码并对比理论",
    },
    "report_agent": {
        "agentCode":    "89468b5f-abbe-4d5a-a717-a0fcda29b9b3",
        "agentVersion": "1788229915815",  # v1.0（已上线，周行远创建）
        "kbIds":        [],
        "description":  "汇报 Agent — 聚合各 Agent 产出，按科研汇报结构成文",
    },
}
