# AI for Comm — 阶段交付说明（致周行远）

**交付人**：B 角色（陈洛安） · **日期**：2026-09-02 · **对象**：周行远（架构师）

---

## 0. 一句话总结

你 08-31 提的 5 套 Agent 动作规范已全部落进提示词；"仿真 Agent + 汇报 Agent"两个方向已按你点名各新建 1 个 Agent（均已在平台上线、凭证回填）；本轮攻克了 **sim 仿真"真执行闭环"**（平台出代码 → 本地实跑 → 理论对比出图）；评测集 37 题**全部跑完**：35 题 ✅（含新增 collab-05 sim→verify 协作通过），1 题（collab-06 report→verify）因平台对 report_agent 持续返回空回复未跑通，需你平台侧排查（详见 §5）。

---

## 1. 动作规范落地（⚠️ 需你在平台重新发布才生效）

你 08-31 消息里给 5 类 Agent 定的动作规范，本轮已写入对应提示词源文件：

| Agent | 固化规范 | 改动位置 | 平台现状 |
|---|---|---|---|
| **math** | 推导三步法：推导 → 符号复算 → 边界检验（SNR→0/∞、B→0 合理性） | `prompts/math_system.md` | ⚠️ 仍 v2.0，需重发 |
| **hw** | 验证闭环：规格 → Verilog → 仿真执行（写明命令）→ 断言波形结果；禁止交"没仿真过的代码" | `prompts/hw_system.md` | ⚠️ 仍 v7.2，需重发 |
| **verify** | 清单式校验：量纲 / 单调性 / 特殊值代入 / 文献对照四项各给结论（替代原整体打分） | `prompts/verify_system.md`（整份重写） | ⚠️ 仍 v5.1，需重发 |
| **lit_review** | 综述三步：检索 → 主题聚类 → GB/T 7714 国标引用 | `prompts/lit_review_system.md` | ⚠️ 仍 v1.0，需重发 |
| **comm** | —（你未点名，按最小改动原则未动） | — | v5.0 不动 |

> 注意：**verify 重写保留了【通过】【不通过】前缀**，judge 自动判定与 orchestrator 的 dual_verify 依赖该前缀，不受影响。
> "仿真五步法"归口到新建的 sim_agent（见下），hw/math 内仅做配套强化。

---

## 2. 新增 2 个 Agent（你已创建并上线，凭证已回填 config.py ✅）

| Agent | 定位 | agentCode | agentVersion | 说明 |
|---|---|---|---|---|
| **sim_agent** | 通信链路蒙特卡洛仿真与理论对照（BER/容量/星座图/衰落/MIMO/信道编码） | `c1c9aa5f-f657-49d0-9999-25a2969c3345` | v1.0 · 1787760897423 | 提示词 `prompts/sim_system.md`；封装 `simulate_ber` / `simulate_capacity` + **think_verified 真执行闭环** |
| **report_agent** | 报告主编：把多 Agent 产出统稿为固定 7 章节科研汇报（摘要/研究问题/方法/结果/结论/局限与下一步/材料清单） | `89468b5f-abbe-4d5a-a717-a0fcda29b9b3` | v1.0 · 1788229915815 | 提示词 `prompts/report_system.md`；`compile_report(title, materials, audience)` 聚合多 Agent 产出 |

**为什么必须新建**：现有 5 Agent 中——math 只推导不跑数值；hw 只做 Verilog 仿真（BER 曲线非其领域）；comm 知识问答不执行代码；verify 只校验不产出；lit_review 只做综述。"仿真五步法（不许交没跑过的代码）"和"科研汇报全流程"在旧架构里没有归属，故各新建 1 个。

**接入点**（本地代码全部就位）：`core/config.py` 注册、`webui.py` 7 Agent 全量注册（sim 走真执行分支）、`tests/run_eval.py` 注册 + collab 真执行包装、评测集已加 sim-01/02、report-01/02、collab-05/06。

---

## 3. sim 真执行闭环（本轮核心攻坚）

**机制**：sim_agent 平台出代码 → 本地提取 → venv 实际执行 → 结果回灌 → 理论曲线对比出图（semilogy PNG）→ 退出码/产物记入评测。

**踩坑与修复**：
1. 平台 sim_agent 输出代码是 **4 空格缩进的裸代码、无 ```python 围栏** → 原 `_extract_python` 正则提取失败，真执行被静默跳过 → 增加回退提取（定位 `import` 行起，截到下一个【章节】标记止）+ `textwrap.dedent` 统一缩进（首行缩进不一致会 IndentationError）。
2. venv 补装 `scipy`（平台代码用 `from scipy.special import erfc`）。
3. `run_eval.py` direct 模式 sim_agent 改走 `think_verified`，真执行 meta（代码提取✓/退出码/PNG 列表/stderr）置输出**头部**，保证 HTML 前 300 字预览可见。

**实测验证（sim-01/02）**：
- sim-01：BPSK 仿真 vs 理论 Q(√(2·Eb/N0))，退出码 0，产出 `bpsk_ber_awgn.png`
- sim-02：BPSK vs QPSK 同图对比，退出码 0，产出 `ber_comparison.png`
- 0~7 dB 双曲线吻合、8~10 dB 蒙特卡洛波动符合统计特性、中文字体正常

---

## 4. 评测全家桶（评测集 v1.2 · 37 题）

| 批次 | 题目 | 结果 | 证据 |
|---|---|---|---|
| direct 直答 | 27 题（math6 / comm6 / hw6 / lit5 / sim2 / report2） | ✅ 全部完成，待人工按 answer_points 打分 | `score_sheet_20260902_110236.html`（27 题可交互评分表：要点勾选→自动算分/备注/导出） |
| judge 判定 | 5 题（verify-01~05） | ✅ **5/5 命中**【通过】判定 | 总表 8 处自动命中 |
| collab 协作 | collab-01 math→verify / collab-02 comm→verify / collab-04 lit→verify | ✅ **3/3 通过**（122~329s） | `eval_20260902_091436` |
| collab 协作 | collab-05 sim→verify（**新增，真执行闭环链路**） | ✅ **通过**（209.4s；首跑遇平台空回复，重试后通过） | `eval_20260902_131712` |
| collab 协作 | collab-06 report→verify（**新增**） | ❌ 平台对 report_agent 持续返回**空回复**（两次运行、含重试均空） | `outputs/eval_collab56*.log` |
| — | collab-03 hw→verify | ⏸ 平台侧挂起链路，评测已排除 | — |

**sim 真执行**：2/2 题触发闭环，退出码 0，PNG 双图产出（见 `outputs/sim/`）；collab-05 中 sim 同样走真执行，verify 基于真实仿真结果判【通过】。

**全量总表**：`eval_summary_20260902_131848.html/csv` — **37 题**（direct 27 + judge 5 + collab 5），自动命中 **9**（judge 5 + collab 4，collab-06 平台异常未计入）。

> collab-06 备注：run_collab 的 sim 真执行包装曾引入 `RecursionError`（think_verified 内部调 self.think 被 wrapper 顶替导致无限递归），已修复（wrapper 调用期间临时解除覆盖）。该 bug 只影响 sim 协作题，不影响 direct。

---

## 5. 需要你（周行远）在平台侧处理的事项

| # | 事项 | 优先级 | 说明 |
|---|---|---|---|
| 1 | **math / hw / verify / lit_review 四份提示词重新发布升版本** | 高 | 新规范只在本地方案里，平台 agentVersion 未动。System Prompt 全文粘贴 `prompts/` 对应 md 后发布，回填新 version 给我 |
| 2 | **hw v7.2 间歇性 `LLM_INVOKE_ERROR` / 无规划任务结果** | 高 | direct 批 hw 6 题意外全成功（间歇性），建议查「任务规划套件」节点模型绑定——v6.0 曾修好过同类问题 |
| 3 | **collab-03（hw→verify）平台挂起** | 中 | 等待 7 分钟无响应致评测进程卡死，已用 `--exclude collab-03` 规避。建议查 hw→verify 协作调度的平台日志 |
| 4 | **report_agent 平台持续空回复（collab-06 未跑通的主因）** | **高** | collab-06 两次运行 + 自动重试均返回空回复；且 direct 模式 report-01 也空（report-02 正常，1/2 成功率）。**疑点**：你创建 report_agent 时平台描述为"输出固定字段 JSON 的报告主编"，与本地 `prompts/report_system.md`（科研汇报 7 章节文本）定位不一致——请核对平台侧 System Prompt 是否贴错/贴成 JSON 输出版，并检查该 Agent 的会话/模型配置 |
| 5 | **（可选）sim 提示词强化代码围栏输出** | 低 | 平台输出裸缩进代码已做本地兼容；若提示词强制 ```python 围栏可减少兼容负担 |

---

## 6. 当前 7 Agent 凭证总表（config.py 实况）

| Agent | agentCode | agentVersion | 知识库 | 状态 |
|---|---|---|---|---|
| math_agent | `d0778d9a-16b1-4e0b-81d7-d060bdfed564` | v2.0 · 1786194666467 | t6doo3pjacqe | ✅ |
| verify_agent | `fed235c6-e97c-431e-b7e1-2cec6200ad9d` | v5.1 · 1788075577472 | — | ✅ |
| comm_agent | `72d8241c-55cf-4dc7-9f2a-d9e464ff13b8` | v5.0 · 1787757082841 | jka3mxb19y08 / anb7bpimm2jn | ✅ |
| hw_agent | `62d77ba3-1a25-4b67-8728-13617e543e19` | v7.2 · 1786113673445 | jfoi1hlf60e7 / d8xgrvwu8zr7 | ⚠️ 间歇 LLM_INVOKE_ERROR |
| lit_review_agent | `ada4212a-c471-42a7-84a0-26e7a23b520f` | v1.0 · 1787753150262 | jka3mxb19y08 / anb7bpimm2jn | ✅ |
| sim_agent | `c1c9aa5f-f657-49d0-9999-25a2969c3345` | v1.0 · 1787760897423 | — | ✅（真执行闭环） |
| report_agent | `89468b5f-abbe-4d5a-a717-a0fcda29b9b3` | v1.0 · 1788229915815 | — | ⚠️ 平台偶发空回复（direct 1/2、collab 未通），疑平台配置与本地 prompt 不一致 |

---

## 7. 本交付包文件清单

| 类别 | 文件 | 用途 |
|---|---|---|
| 说明 | `交付说明_致周行远_20260902.md` | 本文档 |
| 提示词 | `prompts/math_system.md` `comm_system.md` `hw_system.md` `verify_system.md` `lit_review_system.md` `sim_system.md` `report_system.md` | 平台发布全文粘贴用 |
| Agent 源码 | `agents/sim_agent.py` `agents/report_agent.py`（新增）`agents/tools.py`（既有工具参考） | 真执行/汇报逻辑 |
| 配置 | `core/config.py` | 7 Agent 凭证 |
| 评测集 | `evals/tasks.json`（v1.2·37题）`evals/README.md` | 题库与用法 |
| 评测工具 | `tests/run_eval.py`（--exclude/--mode/--agent）`merge_eval_results.py` `make_score_sheet.py` | 跑评/合并/评分 |
| 结果 | `eval_summary_20260902_131848.html/csv`（**37 题总表**）、`score_sheet_20260902_110236.html`（27 题评分表）、`eval_20260902_131712.html`（collab-05/06 协作批）、`eval_20260902_110150.html`（sim 批详情） | 验收数据 |
| 图 | `outputs/sim/bpsk_ber_awgn.png`、`ber_comparison.png` | sim 真执行产出 |
