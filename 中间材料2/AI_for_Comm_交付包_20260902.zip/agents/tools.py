# -*- coding: utf-8 -*-
"""
agents/tools.py —— 计算器工具

按实践手册 07 章 B 角色任务清单："计算器工具（数值计算函数封装）"。
OpenTrek 平台暂未启用原生工具调用（function calling），本文件作为：
  1. Agent 推理时的"事实参考"（可被注入 Prompt 让 AI 校对自己的计算）
  2. 本地预检（如 tests/test_single.py 中的 local_precheck）使用
  3. 测试用例的标准答案生成（避免依赖 AI 计算）

封装常见单位换算与信道容量公式，与香农定理对应。
"""
import math


# ═══════════════════════════════════════════════════
#  基础单位换算
# ═══════════════════════════════════════════════════

def db_to_linear(db: float) -> float:
    """dB 转线性值：linear = 10^(dB/10)"""
    return 10 ** (db / 10)


def linear_to_db(linear: float) -> float:
    """线性值转 dB：db = 10·log10(linear)"""
    if linear <= 0:
        raise ValueError("linear value must be > 0 for dB conversion")
    return 10 * math.log10(linear)


def mhz_to_hz(mhz: float) -> float:
    """MHz 转 Hz"""
    return mhz * 1e6


def hz_to_mhz(hz: float) -> float:
    """Hz 转 MHz"""
    return hz / 1e6


# ═══════════════════════════════════════════════════
#  对数与数学基础
# ═══════════════════════════════════════════════════

def log2(x: float) -> float:
    """以 2 为底的对数（信息论推导核心）"""
    if x <= 0:
        raise ValueError("log2 requires x > 0")
    return math.log2(x)


def shannon_capacity(bandwidth_hz: float, snr_linear: float) -> float:
    """香农信道容量（bit/s）：C = B · log₂(1 + S/N)"""
    if bandwidth_hz <= 0:
        raise ValueError("bandwidth must be > 0")
    if snr_linear < 0:
        raise ValueError("SNR must be >= 0")
    return bandwidth_hz * math.log2(1 + snr_linear)


def awgn_capacity_from_db(bandwidth_mhz: float, snr_db: float) -> float:
    """便捷版本：带宽(MHz) + SNR(dB) → 信道容量 (bps)"""
    bw_hz = mhz_to_hz(bandwidth_mhz)
    snr_lin = db_to_linear(snr_db)
    return shannon_capacity(bw_hz, snr_lin)


# ═══════════════════════════════════════════════════
#  自测（可直接 python agents/tools.py 验证）
# ═══════════════════════════════════════════════════

if __name__ == "__main__":
    # 案例 1：经典 AWGN 20MHz/30dB → ~199.5 Mbps
    c_bps = awgn_capacity_from_db(20, 30)
    print(f"[1] AWGN 20MHz/30dB → {c_bps/1e6:.3f} Mbps  (期望 ≈199.34)")

    # 案例 2：单位换算自检
    print(f"[2] 30 dB → {db_to_linear(30):.0f} 线性值  (期望 1000)")
    print(f"[3] 1000 线性 → {linear_to_db(1000):.0f} dB  (期望 30)")

    # 案例 3：信噪比加倍 vs 容量
    for snr in [10, 20, 30, 40]:
        c = awgn_capacity_from_db(20, snr)
        print(f"[4] SNR={snr}dB → {c/1e6:.2f} Mbps")

    # 案例 4：带宽加倍 vs 容量（SNR 不变时容量加倍）
    c1 = awgn_capacity_from_db(10, 20)
    c2 = awgn_capacity_from_db(20, 20)
    print(f"[5] B=10MHz/20dB={c1/1e6:.2f} Mbps, B=20MHz/20dB={c2/1e6:.2f} Mbps, ratio={c2/c1:.2f}")
